import os
import sys
import asyncio

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from pydantic import BaseModel, Field
from crewai import Agent, Task, Crew, Process, LLM
from tools.math_auditor import audit_invoice_math
from tools.policy_guard import flag_compliance_risk

API_KEY = "AQ.Ab8RN6Kgnk4fCn9elGNH0v3-zhKHQadI9PlGJhoN3E8KtwIlHg"
my_llm = LLM(model="gemini/gemini-3.1-flash-lite", api_key=API_KEY)

class FinancialAuditReport(BaseModel):
    vendor_name: str = Field(..., description="ভেন্ডরের নাম")
    invoice_number: str = Field(..., description="ইনভয়েস নম্বর")
    math_audit_verdict: str = Field(..., description="গাণিতিক অডিটের ফলাফল")
    policy_compliance_status: str = Field(..., description="কমপ্লায়েন্স স্ট্যাটাস")
    final_approval_status: str = Field(..., description="APPROVAL_RECOMMENDED অথবা REJECT_PAYMENT")

async def run_audit():
    auditor = Agent(
        role="চিফ ফিন্যান্সিয়াল অডিটর",
        goal="ইনভয়েসের সংখ্যা এবং বাজেট সিলিং ভ্যালিডেট করা",
        backstory="কর্পোরেট একাউন্টিং ও ফ্রড প্রতিরোধে অভিজ্ঞ ফরেনসিক অডিটর।",
        tools=[audit_invoice_math, flag_compliance_risk],
        llm=my_llm,
        verbose=True
    )
    
    task = Task(
        description=(
            "ভেন্ডর: 'Global Infrastructure Tech', ইনভয়েস: 'INV-9092'\n"
            "সাবটোটাল: $20,000, ট্যাক্স: 15%, ডিসকাউন্ট: $1,000, বিলকৃত মোট: $23,500\n"
            "বাজেট সিলিং: $21,000।\n"
            "audit_invoice_math ও flag_compliance_risk টুল দিয়ে ভ্যালিডেট করে FinancialAuditReport স্কিমায় আউটপুট দাও।"
        ),
        expected_output="FinancialAuditReport স্কিমা অনুযায়ী ভ্যালিডেটেড JSON",
        agent=auditor,
        output_json=FinancialAuditReport
    )
    
    crew = Crew(agents=[auditor], tasks=[task], process=Process.sequential)
    return await crew.kickoff_async()

if __name__ == "__main__":
    result = asyncio.run(run_audit())
    print("\n==================================")
    print("🏆 ফিন্যান্সিয়াল অডিট মডুলার সিএলআই আউটপুট:")
    print("==================================")
    print(result)
