from crewai.tools import tool

@tool("flag_compliance_risk")
def flag_compliance_risk(billed_total: float, approved_budget_ceiling: float) -> str:
    """Verifies invoice ceiling limits against enterprise procurement rules."""
    if billed_total > approved_budget_ceiling:
        over = billed_total - approved_budget_ceiling
        return f"POLICY_VIOLATION: Exceeds approved budget ceiling by ${over:,.2f}."
    return f"COMPLIANT: Within approved limit of ${approved_budget_ceiling:,.2f}."
