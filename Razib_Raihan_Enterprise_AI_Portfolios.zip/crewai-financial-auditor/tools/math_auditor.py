from crewai.tools import tool

@tool("audit_invoice_math")
def audit_invoice_math(subtotal: float, tax_rate_percent: float, discount_applied: float, billed_total: float) -> str:
    """Performs rigorous forensic math validation on invoice numbers to detect discrepancies."""
    expected_tax = subtotal * (tax_rate_percent / 100.0)
    calculated_grand_total = round((subtotal + expected_tax) - discount_applied, 2)
    difference = round(billed_total - calculated_grand_total, 2)
    
    if abs(difference) > 0.05:
        return f"DISCREPANCY_DETECTED: Billed total ${billed_total:,.2f} does not match expected ${calculated_grand_total:,.2f}. Variance: ${difference:,.2f}"
    return f"MATH_VERIFIED: All figures match exactly with billed total ${billed_total:,.2f}."
