# Autonomous B2B Lead Enrichment Engine (CrewAI + Gemini 3.1)

Production-grade multi-agent autonomous system for high-throughput enterprise B2B lead enrichment, deterministic scoring, and structured extraction.

## Features
- **Deterministic Math & Scoring:** Custom Python algorithms prevent LLM hallucination in deal sizing.
- **Sub-Second Extraction:** Lightweight HTTP scrapers without browser overhead.
- **Type-Safe Validation:** Powered by Pydantic schemas.
- **Enterprise Rate-Limiting:** Configured with `max_rpm` concurrency controls.

## Tech Stack
- CrewAI
- Google Gemini 3.1 Flash-Lite
- Pydantic v2
- FastAPI / SQLite Persistence

## Author
Razib Raihan (Enterprise AI & Multi-Agent Systems Engineer)
