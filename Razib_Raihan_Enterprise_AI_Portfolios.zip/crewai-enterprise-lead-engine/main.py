import os
import sys
import asyncio

# মডিউল পাথ কনফিগারেশন
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from pydantic import BaseModel, Field
from crewai import Agent, Task, Crew, Process, LLM
from tools.scraper import scrape_company_profile
from tools.scoring import compute_lead_priority_score

API_KEY = "AQ.Ab8RN6Kgnk4fCn9elGNH0v3-zhKHQadI9PlGJhoN3E8KtwIlHg"
my_llm = LLM(model="gemini/gemini-3.1-flash-lite", api_key=API_KEY)

class EnterpriseLeadOutput(BaseModel):
    company_name: str = Field(..., description="কোম্পানির নাম")
    extracted_summary: str = Field(..., description="কোর সার্ভিস সামারি")
    priority_tier: str = Field(..., description="স্কোর ও টায়ার")
    strategic_sales_angle: str = Field(..., description="পিচ স্ট্র্যাটেজি")

async def run_pipeline(company: str, url: str, team: int, budget: int):
    researcher = Agent(
        role="মার্কেট রিসার্চ অ্যানালিস্ট",
        goal="কোম্পানি প্রোফাইল বের করা",
        backstory="ওয়েব স্ক্র্যাপিং ও কর্পোরেট অ্যানালাইসিস স্পেশালিস্ট।",
        tools=[scrape_company_profile],
        llm=my_llm,
        verbose=True
    )
    strategist = Agent(
        role="বিটুবি স্ট্র্যাটেজিস্ট",
        goal="লিড প্রায়োরিটি নির্ধারণ করা",
        backstory="উচ্চ-মূল্যের বিটুবি চুক্তি বিশ্লেষক।",
        tools=[compute_lead_priority_score],
        llm=my_llm,
        verbose=True
    )
    
    t1 = Task(
        description=f"অডিট ওয়েবসাইট: {url}", 
        expected_output="সারসংক্ষেপ", 
        agent=researcher
    )
    t2 = Task(
        description=f"টিম সাইজ {team} ও বাজেট ${budget}-এর জন্য স্কোর হিসাব করো। প্রাপ্ত তথ্যের ভিত্তিতে EnterpriseLeadOutput স্কিমায় ভ্যালিডেট করো।",
        expected_output="EnterpriseLeadOutput স্কিমা অনুযায়ী JSON",
        agent=strategist,
        context=[t1],
        output_json=EnterpriseLeadOutput
    )
    
    crew = Crew(
        agents=[researcher, strategist], 
        tasks=[t1, t2], 
        process=Process.sequential, 
        max_rpm=30
    )
    return await crew.kickoff_async()

if __name__ == "__main__":
    result = asyncio.run(run_pipeline("Docker Inc", "https://www.docker.com", 250, 65000))
    print("\n==================================")
    print("🏆 মডুলার সিএলআই থেকে এক্সিকিউট হওয়া আউটপুট:")
    print("==================================")
    print(result)
