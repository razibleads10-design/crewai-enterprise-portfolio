from crewai.tools import tool

@tool("compute_lead_priority_score")
def compute_lead_priority_score(estimated_team_size: int, deal_potential_usd: int) -> str:
    """Calculates algorithmic enterprise priority score (0-100) based on scale and budget."""
    base_score = min(40, (estimated_team_size / 20) * 10)
    deal_score = min(60, (deal_potential_usd / 20000) * 20)
    final_score = int(base_score + deal_score)
    tier = "TIER_1_ENTERPRISE" if final_score >= 75 else ("TIER_2_MIDMARKET" if final_score >= 50 else "TIER_3_STANDARD")
    return f"SCORE: {final_score}/100 | TIER: {tier}"
