import urllib.request
import re
from crewai.tools import tool

@tool("scrape_company_profile")
def scrape_company_profile(website_url: str) -> str:
    """Scrapes essential business context from a company website URL."""
    try:
        req = urllib.request.Request(
            website_url,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        with urllib.request.urlopen(req, timeout=12) as response:
            html = response.read().decode('utf-8', errors='ignore')
            clean_text = re.sub(r'<script.*?</script>', '', html, flags=re.DOTALL)
            clean_text = re.sub(r'<style.*?</style>', '', clean_text, flags=re.DOTALL)
            clean_text = re.sub(r'<[^<]+?>', ' ', clean_text)
            clean_text = ' '.join(clean_text.split())
            return clean_text[:1200] if clean_text else "No extractable text found."
    except Exception as e:
        return f"Extraction Warning: {str(e)}"
